﻿import io
import pymupdf as fitz
from docx import Document
from PIL import Image, ImageDraw

def create_sample_pdf():
    doc = fitz.open()
    colors = [
        ("Mountain Sunrise", (240, 100, 80)),
        ("Ocean Horizon", (40, 140, 220)),
        ("Forest Path", (50, 160, 90)),
        ("Golden Autumn", (230, 170, 40)),
        ("Cosmic Nebula", (130, 70, 210)),
        ("Desert Dunes", (210, 130, 50)),
        ("City Skyline", (70, 100, 140)),
        ("Tropical Beach", (30, 180, 180)),
        ("Spring Bloom", (230, 100, 160)),
    ]
    for idx, (title, rgb) in enumerate(colors):
        page = doc.new_page(width=595, height=842)
        page.insert_text((50, 60), f"Sample Document Page {idx+1} - {title}", fontsize=16)
        page.insert_text((50, 85), "This sample document demonstrates high-resolution image extraction.", fontsize=11)
        
        img = Image.new("RGB", (800, 600), color=rgb)
        d = ImageDraw.Draw(img)
        d.rectangle([(20, 20), (780, 580)], outline="white", width=4)
        d.text((50, 80), f"Sample Photo {idx+1}", fill="white")
        d.text((50, 140), title, fill="yellow")
        d.text((50, 500), "DocImagePrint Test Asset", fill="white")
        
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=95)
        
        rect = fitz.Rect(50, 120, 545, 490)
        page.insert_image(rect, stream=buf.getvalue())
        
    doc.save("samples/sample_presentation.pdf")
    doc.close()
    print("Created samples/sample_presentation.pdf")

create_sample_pdf()
