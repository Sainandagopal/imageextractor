﻿import io
import pymupdf as fitz
from docx import Document
from PIL import Image, ImageDraw
from fastapi.testclient import TestClient

from app.extractor import DocumentImageExtractor
from app.pdf_builder import PDFPrintBuilder
from app.main import app

def create_mock_pdf_with_images(num_images=10) -> bytes:
    doc = fitz.open()
    for i in range(num_images):
        page = doc.new_page(width=400, height=400)
        img = Image.new("RGB", (200, 200), color=(30 * (i + 1) % 255, 100, 150))
        d = ImageDraw.Draw(img)
        d.text((20, 80), f"Test Photo #{i+1}", fill="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        
        rect = fitz.Rect(50, 50, 250, 250)
        page.insert_image(rect, stream=buf.getvalue())
    b = doc.tobytes()
    doc.close()
    return b

def create_mock_docx_with_images(num_images=4) -> bytes:
    doc = Document()
    for i in range(num_images):
        doc.add_heading(f"Section {i+1}", level=1)
        img = Image.new("RGB", (150, 150), color=(100, 40 * (i+1) % 255, 80))
        d = ImageDraw.Draw(img)
        d.text((10, 60), f"Docx Img #{i+1}", fill="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        doc.add_picture(buf)
    
    out_buf = io.BytesIO()
    doc.save(out_buf)
    return out_buf.getvalue()

def run_tests():
    print("=== STARTING AUTOMATED TESTS ===")
    
    # 1. Test Extractor on PDF
    pdf_bytes = create_mock_pdf_with_images(10)
    extractor = DocumentImageExtractor(min_dimension=30)
    extracted_pdf = extractor.extract_from_pdf(pdf_bytes)
    print(f"[TEST 1] PDF Image Extraction: Extracted {len(extracted_pdf)} images. Expected 10.")
    assert len(extracted_pdf) == 10, f"Expected 10 images, got {len(extracted_pdf)}"
    
    # 2. Test Extractor on DOCX
    docx_bytes = create_mock_docx_with_images(4)
    extracted_docx = extractor.extract_from_docx(docx_bytes)
    print(f"[TEST 2] DOCX Image Extraction: Extracted {len(extracted_docx)} images. Expected 4.")
    assert len(extracted_docx) == 4, f"Expected 4 images, got {len(extracted_docx)}"
    
    # 3. Test PDF Builder with 9 images per page (Condition: max 9 per paper)
    # 10 images at 9 per page should create exactly 2 pages!
    pdf_out = PDFPrintBuilder.build_printable_pdf(
        images=extracted_pdf,
        images_per_page=9,
        paper_size="a4",
        orientation="portrait",
        show_cut_lines=True,
        show_page_numbers=True
    )
    assert len(pdf_out) > 0, "PDF output is empty"
    
    # Verify generated PDF
    out_doc = fitz.open(stream=pdf_out, filetype="pdf")
    page_count = len(out_doc)
    print(f"[TEST 3] PDF Builder 9/page: Generated PDF has {page_count} pages. Expected 2.")
    assert page_count == 2, f"Expected 2 pages for 10 images at 9/page, got {page_count}"
    out_doc.close()
    
    # 4. Test PDF Builder with 4 images per page
    pdf_out_4 = PDFPrintBuilder.build_printable_pdf(
        images=extracted_pdf,
        images_per_page=4,
        paper_size="letter",
        orientation="landscape"
    )
    out_doc_4 = fitz.open(stream=pdf_out_4, filetype="pdf")
    assert len(out_doc_4) == 3, f"Expected 3 pages for 10 images at 4/page, got {len(out_doc_4)}"
    out_doc_4.close()
    print(f"[TEST 4] PDF Builder 4/page landscape: Generated 3 pages successfully.")
    
    # 5. Test FastAPI HTTP Endpoints
    client = TestClient(app)
    
    # Test index page
    res = client.get("/")
    assert res.status_code == 200, f"Index returned {res.status_code}"
    print("[TEST 5] GET / : OK")
    
    # Test sample generation endpoint
    res_sample = client.post("/api/generate-sample")
    assert res_sample.status_code == 200
    sample_data = res_sample.json()
    assert sample_data["status"] == "success"
    assert sample_data["total_count"] == 9
    print(f"[TEST 6] POST /api/generate-sample: OK ({sample_data['total_count']} sample images generated)")
    
    # Test PDF generation API
    session_id = sample_data["session_id"]
    image_ids = [img["id"] for img in sample_data["images"]]
    
    res_gen_pdf = client.post("/api/generate-pdf", json={
        "session_id": session_id,
        "image_ids": image_ids,
        "images_per_page": 9,
        "paper_size": "a4",
        "orientation": "portrait",
        "margin": "standard",
        "gap": "standard",
        "fit_mode": "contain",
        "show_cut_lines": True,
        "show_labels": True,
        "show_page_numbers": True
    })
    assert res_gen_pdf.status_code == 200
    assert res_gen_pdf.headers["content-type"] == "application/pdf"
    print(f"[TEST 7] POST /api/generate-pdf (9 photos on 1 A4 sheet): OK ({len(res_gen_pdf.content)} bytes)")
    
    # Test ZIP download API
    res_zip = client.post("/api/download-zip", json={
        "session_id": session_id,
        "image_ids": image_ids,
        "images_per_page": 9
    })
    assert res_zip.status_code == 200
    assert res_zip.headers["content-type"] == "application/zip"
    print(f"[TEST 8] POST /api/download-zip: OK ({len(res_zip.content)} bytes)")
    
    print("\n[SUCCESS] ALL TESTS COMPLETED SUCCESSFULLY!")

if __name__ == "__main__":
    run_tests()
