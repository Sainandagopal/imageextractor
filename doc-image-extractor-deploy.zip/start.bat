@echo off
title DocImagePrint - Document Image Extractor & Layout Engine
echo Starting DocImagePrint Server...
python run.py
pause
